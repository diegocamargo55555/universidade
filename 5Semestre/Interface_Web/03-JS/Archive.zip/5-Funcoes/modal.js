(function (n1, n2, n3) {
    let isvalid = false
    console.log("moda", isvalid, n1, n2, n3)    
    function init(params) {
        console.log("init do modal")
    }
    init()
})(1,2,3)