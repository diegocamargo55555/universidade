(function () {
    let isvalid = false
    console.log("menu", isvalid)    
    function init(params) {
        console.log("init menu")
    }
    init()
})()