const teste = function teste() {
    console.log("teclado")
}

teste()