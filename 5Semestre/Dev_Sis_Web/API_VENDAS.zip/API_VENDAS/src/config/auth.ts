export default { // session token
    jwt:{
        secret: 'e11516964f68f08ec3b54f75c694ce04'
    }
}