package org.example.dao;

public interface IConst {
    public static final String stringDeConexao = "jdbc:postgresql://localhost:5432/Curso";
    public static final String usuario = "postgres";
    public static final String senha = "lolseek005";
}